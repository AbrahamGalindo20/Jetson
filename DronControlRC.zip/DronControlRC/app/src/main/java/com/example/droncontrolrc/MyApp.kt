package com.example.droncontrolrc

import android.app.Application
import android.util.Log
import dji.sdk.sdkmanager.DJISDKManager

class MyApp : Application() {

    override fun onCreate() {
        super.onCreate()
        initDJI()
    }

    private fun initDJI() {

        DJISDKManager.getInstance().registerApp(this) { error ->

            if (error == null) {
                Log.d("DJI", "SDK registrado correctamente")
            } else {
                Log.e("DJI", "Error DJI: $error")
            }
        }
    }
}