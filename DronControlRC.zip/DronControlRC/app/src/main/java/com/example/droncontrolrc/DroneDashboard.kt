package com.example.droncontrolrc

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun DroneDashboard() {

    var status by remember { mutableStateOf("🔴 NO CONECTADO") }
    var battery by remember { mutableStateOf("--") }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {

        Text("🚁 DRONE CONTROL PANEL", fontSize = 22.sp)

        Spacer(Modifier.height(20.dp))

        Card {
            Column(Modifier.padding(16.dp)) {
                Text("Estado del dron:")
                Text(status)

                Spacer(Modifier.height(10.dp))

                Text("Batería:")
                Text("$battery %")
            }
        }

        Spacer(Modifier.height(20.dp))

        Button(
            onClick = {
                status = "🟡 CHECKING..."
            },
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("CHECK CONNECTION")
        }

        Spacer(Modifier.height(10.dp))

        Button(
            onClick = {
                battery = "85"
            },
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("GET BATTERY (TEST)")
        }

        Spacer(Modifier.height(10.dp))

        Button(
            onClick = {
                status = "🟢 SIMULATED CONNECTED"
            },
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("SIMULATE CONNECT")
        }
    }
}